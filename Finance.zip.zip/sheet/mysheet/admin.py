from django.contrib import admin
from .models import Main
# Register your models here.
admin.site.register(Main)