from django.db import models

# Create your models here.
class Main(models.Model):
    Date=models.DateField()
    Comm_Long= models.IntegerField()
    Comm_Short=models.IntegerField()
    Comm_long_percent=models.IntegerField()
    Comm_short_percent=models.IntegerField()
    Comm_total=models.IntegerField()
    Comm_Net_position=models.IntegerField()
    NonComm_Long= models.IntegerField()
    NonComm_Short=models.IntegerField()
    NonComm_long_percent=models.IntegerField()
    NonComm_short_percent=models.IntegerField()
    NonComm_total=models.IntegerField()
    NonComm_Net_position=models.IntegerField()
    Total=models.IntegerField()
    

