from django.shortcuts import render , redirect, get_object_or_404
from .models import Main
from datetime import datetime
from django.db.models import Max , Min , Avg
from  django.db.models.functions import  Round


# Create your views here.

def index(request):
    rows=Main.objects.all().order_by('-Date')

    max_values=Main.objects.aggregate(
        commlongmax=Max('Comm_Long'),
        commshortmax=Max('Comm_Short'),
        commtotalmax=Max('Comm_total'),
        commnetmax=Max('Comm_Net_position'),
        noncommlongmax=Max('NonComm_Long'),
        noncommshortmax=Max('NonComm_Short'),          
        noncommtotalmax=Max('NonComm_total'),
        noncommnetmax=Max('NonComm_Net_position'),
        totalmax=Max('Total')
    )

    min_values=Main.objects.aggregate(
        commlongmin=Min('Comm_Long'),
        commshortmin=Min('Comm_Short'),
        commtotalmin=Min('Comm_total'),
        commnetmin=Min('Comm_Net_position'),
        noncommlongmin=Min('NonComm_Long'),
        noncommshortmin=Min('NonComm_Short'),
        noncommtotalmin=Min('NonComm_total'),
        noncommnetmin=Min('NonComm_Net_position'),
        totalmin=Min('Total')
    )

    avg_values = Main.objects.aggregate(
        commlongavg=Round(Avg('Comm_Long'), 3), 
        commshortavg=Round(Avg('Comm_Short'), 3), 
        commtotalavg=Round(Avg('Comm_total'), 3), 
        commnetavg=Round(Avg('Comm_Net_position'), 3), 
        noncommlongavg=Round(Avg('NonComm_Long'), 3), 
        noncommshortavg=Round(Avg('NonComm_Short'), 3), 
        noncommtotalavg=Round(Avg('NonComm_total'), 3), 
        noncommnetavg=Round(Avg('NonComm_Net_position'), 3),
        totalavg=Round(Avg('Total'), 3)
    )
    context={
        'rows':rows,
        'max':max_values,
        'min':min_values,
        'avg':avg_values
    }
    return render(request , "mysheet/index.html",context)


def add_new_row(request):
    

    if request.method == 'POST':
        
        # Get data from form
            Date = request.POST.get('Date', '').strip()
            if not Date:
                Date = datetime.today().strftime('%Y-%m-%d')
            
            comm_long = int(request.POST.get('Comm_Long', 0))
            comm_short = int(request.POST.get('Comm_Short', 0))
            comm_total = comm_long + comm_short
            comm_long_per = (comm_long / comm_total) * 100 if comm_total else 0
            if(comm_long_per - int(comm_long_per)>=0.5):
                comm_long_per=int(comm_long_per)+1
            comm_short_per = (comm_short / comm_total) * 100 if comm_total else 0
            if(comm_short_per - int(comm_short_per)>=0.5):
                comm_short_per=int(comm_short_per)+1
            comm_net = comm_long - comm_short
            non_long = int(request.POST.get('NonComm_Long', 0))
            non_short = int(request.POST.get('NonComm_Short', 0))
            non_total = non_long + non_short
            non_long_per = (non_long / non_total) * 100 if non_total else 0
            if(non_long_per - int(non_long_per)>=0.5):
                non_long_per=int(non_long_per)+1
            non_short_per = (non_short / non_total) * 100 if non_total else 0
            if(non_short_per - int(non_short_per)>=0.5):
                non_short_per=int(non_short_per)+1
            non_net = non_long - non_short
            total = (comm_long + non_long) - (comm_short + non_short)

            # Create new row
            new_row= Main(
                Date=Date,
                Comm_Long=comm_long,
                Comm_Short=comm_short,
                Comm_long_percent=comm_long_per,
                Comm_short_percent=comm_short_per,
                Comm_total=comm_total,
                Comm_Net_position=comm_net,
                NonComm_Long=non_long,
                NonComm_Short=non_short,
                NonComm_long_percent=non_long_per,
                NonComm_short_percent=non_short_per,
                NonComm_total=non_total,
                NonComm_Net_position=non_net,
                Total=total
            )
            new_row.save()
            return redirect('index')
    return render(request , 'mysheet/inputs.html')
            
        
def edit_row(request , row_id):
     row = get_object_or_404(Main, id=row_id)
     if request.method == "POST":
        date = request.POST.get('date') 
        if date:
            row.Date = date 
        comm_long = request.POST.get('Comm_Long') 
        if comm_long: 
            row.Comm_Long = int(comm_long) 
        comm_short = request.POST.get('Comm_Short') 
        if comm_short: 
            row.Comm_Short = int(comm_short) 
        noncomm_long = request.POST.get('NonComm_Long') 
        if noncomm_long: 
            row.NonComm_Long = int(noncomm_long )
        noncomm_short = request.POST.get('NonComm_Short') 
        if noncomm_short: 
            row.NonComm_Short = int( noncomm_short)

        print(f"Date: {date}")
        print(f"Comm Long: {comm_long}")
        print(f"Comm Short: {comm_short}")
        print(f"NonComm Long: {noncomm_long}")
        print(f"NonComm Short: {noncomm_short}")

        
        row.Comm_total = row.Comm_Long + row.Comm_Short
        row.Comm_long_percent = (row.Comm_Long / row.Comm_total) * 100 if row.Comm_total else 0
        row.Comm_short_percent = (row.Comm_Short / row.Comm_total) * 100 if row.Comm_total else 0
        row.Comm_Net_position = row.Comm_Long - row.Comm_Short
        
        row.NonComm_total = row.NonComm_Long + row.NonComm_Short
        row.NonComm_long_percent = (row.NonComm_Long / row.NonComm_total) * 100 if row.NonComm_total else 0
        row.NonComm_short_percent = ( row.NonComm_Short/ row.NonComm_total) * 100 if row.NonComm_total else 0
        row.NonComm_Net_position = row.NonComm_Long - row.NonComm_Short
        row.Total = (row.Comm_Long + row.NonComm_Long) - (row.Comm_Short + row.NonComm_Short)
        


        row.save()
        return redirect('index')
     return render(request , 'mysheet/inputs.html' , {'row':row})

def delete_row(request , row_id):
    row = get_object_or_404(Main , id= row_id)
    row.delete()
    
    return redirect('index')
     
     
    
    
