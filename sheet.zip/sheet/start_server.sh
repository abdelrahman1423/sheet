#!/bin/bash

# Run migrations only if not skipped
if [ "$1" != "skip-migrations" ]; then
    echo "Running migrations..."
    python manage.py makemigrations
    python manage.py migrate
else
    echo "Skipping migrations..."
fi

# Start the server
python manage.py runserver &

# Wait for the server to start
sleep 5

# Open the default web browser
xdg-open http://127.0.0.1:8000/ || start http://127.0.0.1:8000/
