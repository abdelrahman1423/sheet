from django.urls import path
from . import views

urlpatterns=[
    path("" , views.index , name="index"),
    path("new-row/", views.add_new_row , name="add_new_row"),
    path("edit-row/<int:row_id>/" , views.edit_row , name='edit_row'),
    path("delete-row/<int:row_id>/" , views.delete_row , name="delete_row")
]